
import java.io.IOException;

public class SuppressedDemo {

    static class FailingResource implements AutoCloseable {
        @Override
        public void close() throws IOException {
            throw new IOException("close() failed");
        }
    }

    public static void demo() {
        System.out.println("[Optional] Suppressed exceptions demo");
        try {
            causePrimaryThenClose();
        } catch (Exception ex) {
            System.out.println("Primary: " + ex);
            for (Throwable t : ex.getSuppressed()) {
                System.out.println("  Suppressed: " + t);
            }
        }
    }

    private static void causePrimaryThenClose() throws Exception {
        try (FailingResource fr = new FailingResource()) {
            throw new IllegalStateException("primary problem in try");
        }
    }
}