
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Task2FileSum {

    /**
     * TODO:
     *  - Use try-with-resources to open and read the file
     *  - Skip blank lines and lines starting with '#'
     *  - Sum valid integers; collect invalid line numbers
     *  - If file missing, print friendly message and return 0
     *  - Always print "[Task2] finished" from a finally block
     */
    public static int sumFile(String path, List<Integer> invalidLines) {
        int sum = 0;
        try {
            try (BufferedReader br = Files.newBufferedReader(Path.of(path))) {
                String line;
                int lineNo = 0;
                while ((line = br.readLine()) != null) {
                    lineNo++;
                    String t = line.trim();
                    if (t.isEmpty() || t.startsWith("#")) continue;
                    try {
                        sum += Integer.parseInt(t);
                    } catch (NumberFormatException nfe) {
                        invalidLines.add(lineNo);
                    }
                }
            }
        } catch (NoSuchFileException nsf) {
            System.out.println("[Task2] File not found: " + path);
            return 0;
        } catch (IOException ioe) {
            System.out.println("[Task2] I/O error: " + ioe.getMessage());
        } finally {
            System.out.println("[Task2] finished");
        }
        return sum;
    }

    public static void demo() {
        System.out.println("[Task2] Sum numbers from file");
        List<Integer> invalid = new ArrayList<>();
        int result = sumFile("numbers.txt", invalid);
        System.out.println("Sum = " + result);
        System.out.println("Invalid lines = " + invalid);
    }
}
