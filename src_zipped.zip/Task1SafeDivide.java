
import java.util.OptionalInt;

public class Task1SafeDivide {

    public static int unsafeDivide(int a, int b) {
        return a / b;
    }
    public static OptionalInt safeDivide(int a, int b) {
        try {
            int result = a / b;
            return OptionalInt.of(result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");
            return OptionalInt.empty();
        }
    }

    public static void demo() {
        System.out.println("[Task1] Safe Divide");
        System.out.println("10 / 2 = " + safeDivide(10, 2).orElse(-1));
        System.out.println("7 / 0 = " + safeDivide(7, 0).orElse(-1)); // should not crash
    }
}
