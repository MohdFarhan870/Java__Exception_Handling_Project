
Java Exception Handling — 2-Hour Lab (Student Handout)

Time: ~120 minutes  
Topics: try/catch, finally, exception hierarchy, checked vs unchecked, throws, multi-catch, try-with-resources, custom exceptions, suppressed exceptions (optional).

Learning goals

By the end, you can:

Distinguish checked vs unchecked exceptions and decide when to handle vs propagate.

Write try/catch/finally blocks and order catch clauses correctly.

Use multi-catch and try-with-resources.

Design and use a custom checked exception.

Read stack traces and explain failure causes.


What you need

JDK 17+

A terminal / IDE

This starter: src/ folder and numbers.txt


How to run

# from the repo root  
javac -d out $(find src -name "*.java")  
java -cp out lab.exceptions.App

Use App.main to run demos for each task.


---

Part A

Answer the Quiz in Classroom (MCQs + short answers). Skim the code in src/ so you recognize the pieces you'll work on in Part B.


---

Part B

Task 1 — Safe divide (starter: Task1SafeDivide.java)

Implement safeDivide(int a, int b):

Catch ArithmeticException from division by zero.

On divide-by-zero, print a helpful message and return OptionalInt.empty().

In demo(), show both a successful division and divide-by-zero.


Done when: App prints two lines for Task 1 and does not crash on 7/0.

Task 2 — Sum a file with validation (starter: Task2FileSum.java)

Implement sumFile(String path) using try-with-resources:

Read numbers.txt line by line.

Ignore blank lines and allow comments starting with #.

Sum valid integers; collect invalid line numbers (e.g., 12a).

If the file does not exist, print a friendly message and return 0.

Always print "[Task2] finished" from a finally block.

demo() should report total sum and invalid lines.


Stretch: also print how many lines were valid vs invalid.

Task 3 — BankAccount with a checked exception (starter: Task3BankAccount.java)

Create InsufficientFundsException (extends Exception) and use it in withdraw:

deposit(int amount) adds to balance; negative/zero amounts are invalid.

withdraw(int amount) throws InsufficientFundsException if amount > balance or amount ≤ 0.

In demo(), catch the checked exception and print an informative message that includes the shortfall.


Ensure: your catch blocks are specific before any general Exception.

Extras : Suppressed exceptions (starter: SuppressedDemo.java)

Run SuppressedDemo.demo() to see a primary exception and suppressed one printed. Skim the code to see how getSuppressed() works in try-with-resources.


---

Part C — Reflection

Turn in short answers (in the Classroom Reflection assignment):

1. When would you use throws instead of try/catch? Give a concrete example from today’s code.  


2. Show an example stack trace you produced. Annotate where in code it originated.  


3. One way you improved an error message today (before vs after).
---
Submission checklist
[ ] Code compiles: javac -d out $(find src -name "*.java")

[ ] App runs and prints outputs for Task 1–3

[ ] Your reflections are submitted

[ ] (Optional) Suppressed exceptions demo observed
Good luck!