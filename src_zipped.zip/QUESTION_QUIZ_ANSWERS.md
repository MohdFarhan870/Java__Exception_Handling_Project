1. Which is a checked exception? ✅ C. IOException

2. What does finally guarantee? ✅ C. Runs whether or not an exception occurs

3. In what order should multiple catch blocks be written? ✅ C. Specific first, general last

4. For multi-catch (e.g., catch (A | B e)), A and B must… ✅ B. Not be related by subclassing

5. try-with-resources requires resources that… ✅ B. Implement AutoCloseable

6. If code in try throws E1 and the resource’s close() throws E2, then… ✅ B. E1 is primary; E2 is suppressed and available via getSuppressed()

7. Which signature correctly declares a checked exception? ✅ B. void read() throws IOException

8. Best practice is to… ✅ C. Log or wrap with context; use custom exceptions for domain errors

9. Define checked vs unchecked exceptions with one example of each. Checked exceptions are enforced at compile time and must be declared or handled. Example: IOException. Unchecked exceptions occur at runtime and don’t require explicit handling. Example: NullPointerException.

10. When would you use throws instead of try/catch? Use throws when you want to delegate exception handling to the caller—especially in library code or when the method itself can’t meaningfully handle the exception.

11. Why is try-with-resources preferred over manual finally for closing I/O? It ensures automatic and reliable resource cleanup, even when exceptions occur, reducing boilerplate and avoiding subtle bugs.

12. What happens if a more general catch comes before a specific one? The specific catch block becomes unreachable, and the compiler throws an error. Catch blocks must be ordered from specific to general.