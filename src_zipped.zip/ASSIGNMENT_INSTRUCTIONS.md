
You have to complete:
Task 1: Implement safeDivide (handle ArithmeticException, return OptionalInt.empty(), demo in App).

Task 2: Implement sumFile with try-with-resources; track invalid lines; always print a message from finally.

Task 3: Define InsufficientFundsException (checked) and use it in BankAccount.withdraw; handle it specifically in demo().

Reflection:
Create a short-answer item. Prompt (paste):
When would you use throws instead of try/catch? Give an example from today’s code.
Paste an example stack trace you produced and annotate where it originated.
Show one error message you improved today (before vs after).

Classroom Assignment — Hands-on Lab (70–80 min)

Deliverables: Update the starter code to complete Tasks 1–3. Push your code or upload your modified src/ folder. Use App.main to demonstrate.

Rubric (100 pts)

(15) Task 1: Catch divide-by-zero; returns OptionalInt.empty(); helpful message

(30) Task 2: Correct try-with-resources; invalid lines tracked; friendly errors; finally used

(35) Task 3: Custom checked exception; correct throws; specific catch; clear messages

(10) Code quality: meaningful messages, method names; no dead catch order

(10) Reflection answers (clarity and accuracy)


Submission format: Attach a screenshot or paste terminal output for each task + your code. Include your reflection answers in the Classroom "Reflection" item.