
Classroom Quiz — Exception Handling (10–15 min)

Multiple choice (pick one)

1. Which is a checked exception?  
   A. NullPointerException  B. ArithmeticException  C. IOException  D. ArrayIndexOutOfBoundsException


2. What does finally guarantee?  
   A. Runs only if a catch handles the exception  
   B. Runs only when an exception occurs  
   C. Runs whether or not an exception occurs  
   D. Prevents exceptions from propagating


3. In what order should multiple catch blocks be written?  
   A. Any order  
   B. General first, specific last  
   C. Specific first, general last  
   D. Alphabetical


4. For multi-catch (e.g., catch (A | B e)), A and B must…  
   A. Be related by subclassing  
   B. Not be related by subclassing  
   C. Always be checked exceptions  
   D. Always be unchecked exceptions


5. try-with-resources requires resources that…  
   A. Extend Throwable  
   B. Implement AutoCloseable  
   C. Are final variables  
   D. Are in java.io


6. If code in try throws E1 and the resource’s close() throws E2, then…  
   A. E2 replaces E1  
   B. E1 is primary; E2 is suppressed and available via getSuppressed()  
   C. Both are lost  
   D. Only E2 is thrown


7. Which signature correctly declares a checked exception?  
   A. void read()  
   B. void read() throws IOException  
   C. void read() throws NullPointerException  
   D. void read() throws RuntimeException


8. Best practice is to…  
   A. Catch Exception and ignore it  
   B. Convert all exceptions to RuntimeException without message  
   C. Log or wrap with context; use custom exceptions for domain errors  
   D. Print the stack trace and continue silently

Short answer

9. Define checked vs unchecked exceptions with one example of each.  


10. When would you use throws instead of try/catch?  


11. Why is try-with-resources preferred over manual finally for closing I/O?  


12. What happens if a more general catch comes before a specific one?