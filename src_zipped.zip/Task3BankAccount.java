
public class Task3BankAccount {

    public static class InsufficientFundsException extends Exception {
        private final int shortfall;
        public InsufficientFundsException(int shortfall) {
            super("Insufficient funds; shortfall=" + shortfall);
            this.shortfall = shortfall;
        }
        public int getShortfall() { return shortfall; }
    }

    public static class BankAccount {
        private final String owner;
        private int balance;

        public BankAccount(String owner, int openingBalance) {
            this.owner = owner;
            this.balance = openingBalance;
        }

        public void deposit(int amount) {
            if (amount <= 0) throw new IllegalArgumentException("amount must be > 0");
            balance += amount;
        }

        /**
         * TODO:
         *  - Throw InsufficientFundsException when amount > balance
         *  - Throw IllegalArgumentException when amount <= 0
         *  - Otherwise deduct from balance
         */
        public void withdraw(int amount) throws InsufficientFundsException {
            if (amount <= 0) throw new IllegalArgumentException("amount must be > 0");
            if (amount > balance) throw new InsufficientFundsException(amount - balance);
            balance -= amount;
        }

        public int getBalance() { return balance; }
        public String getOwner() { return owner; }
    }

    public static void demo() {
        System.out.println("[Task3] BankAccount with checked exception");
        BankAccount acct = new BankAccount("Asha", 100);
        acct.deposit(50);
        System.out.println("Balance after deposit: " + acct.getBalance());
        try {
            acct.withdraw(120);
            System.out.println("Withdrew 120. Balance: " + acct.getBalance());
            acct.withdraw(1000); // should trigger checked exception
        } catch (InsufficientFundsException ife) {
            System.out.println("Withdraw failed: " + ife.getMessage() + " (shortfall=" + ife.getShortfall() + ")");
        } catch (IllegalArgumentException iae) {
            System.out.println("Bad input: " + iae.getMessage());
        }
        System.out.println("Final balance: " + acct.getBalance());
    }
}
