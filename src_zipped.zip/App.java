
public class App {
    public static void main(String[] args) {
        System.out.println("=== Java Exception Handling Lab ===");
        Task1SafeDivide.demo();
        System.out.println();
        Task2FileSum.demo();
        System.out.println();
        Task3BankAccount.demo();
        System.out.println();
        SuppressedDemo.demo(); // optional
    }
}