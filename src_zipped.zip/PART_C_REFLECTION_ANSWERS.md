1. When would you use throws instead of try/catch?
You use throws when you want to delegate exception handling to the caller—especially in utility methods or APIs where the method itself can’t meaningfully recover from the error.

Example from today’s code:

java
```
public String readFile(String path) throws IOException {
    return Files.readString(Paths.get(path));
}
```
🔍 Why? This method is part of a utility class used across multiple modules. Instead of cluttering it with try/catch, I let the calling code decide how to handle IOException, which varies depending on context (e.g., logging, fallback, or user notification).

2. Example stack trace produced today (with annotation):
Code
Exception in thread "main" java.lang.NumberFormatException: For input string: "abc"
    at java.base/java.lang.NumberFormatException.forInputString(NumberFormatException.java:67)
    at java.base/java.lang.Integer.parseInt(Integer.java:668)
    at com.mohd.utils.Parser.parseIntSafe(Parser.java:12)
    at com.mohd.Main.main(Main.java:5)
🧩 Annotation:

Main.java:5 → Called parseIntSafe("abc") with invalid input

Parser.java:12 → Internally used Integer.parseInt, which threw the exception

Root cause: "abc" is not a valid integer string

💡 Fix: Added input validation before parsing to avoid this.

3. One way I improved an error message today
Before:

java
```
throw new IllegalArgumentException("Invalid input");
```
After:
java
```
throw new IllegalArgumentException("Expected numeric string but got: '" + input + "'. Please check the format.");
```
🎯 Why it’s better:

Specifies what was wrong ('abc' instead of a number)

Suggests a fix (check format)

Easier to debug when scanning logs or handling user input errors